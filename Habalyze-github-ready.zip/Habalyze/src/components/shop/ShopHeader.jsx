import React from 'react';
import { Button } from '@/components/ui/button';
import { CreditCard, Heart, ShoppingBag } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { cn } from '@/lib/utils';

export default function ShopHeader({ user, wishlistCount, onWishlistClick }) {
  const navigate = useNavigate();

  return (
    <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-pink-500 text-white py-6 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center">
              <ShoppingBag className="w-7 h-7" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Tienda de Avatar</h1>
              <p className="text-amber-100 text-sm">Personaliza tu estilo</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3 flex-wrap justify-center">
            <Button 
              variant="ghost" 
              onClick={onWishlistClick}
              className="text-white hover:bg-white/20"
            >
              <Heart className={cn("w-5 h-5 mr-1", wishlistCount > 0 && "fill-current")} />
              {wishlistCount}
            </Button>
            <div className="bg-white/20 backdrop-blur rounded-xl px-4 py-2 flex items-center gap-2">
              <span className="text-2xl">💰</span>
              <p className="text-xl font-bold">{user?.coins || 0}</p>
            </div>
            <div className="bg-violet-500/30 backdrop-blur rounded-xl px-4 py-2 flex items-center gap-2">
              <span className="text-2xl">💎</span>
              <p className="text-xl font-bold">{user?.gems || 0}</p>
            </div>
            <Button onClick={() => navigate(createPageUrl('BuyCoins'))} size="sm" className="bg-white text-amber-600 hover:bg-amber-50">
              <CreditCard className="w-4 h-4 mr-1" /> Monedas
            </Button>
            <Button onClick={() => navigate(createPageUrl('BuyGems'))} size="sm" className="bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white hover:opacity-90">
              💎 Gemas
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}