const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from 'react';

import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ArrowLeft, Sparkles, User, Store, Palette, Shirt, Scissors, Save, FolderOpen, Plus, Trash2, Wand2, Zap, Heart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

import PixelAvatar, { 
  skinTones, 
  faceExpressions,
  hairStyles, 
  hairColors, 
  shirtStyles, 
  pantsStyles, 
  shoesStyles, 
  clothingColors,
  accessories,
  pets,
  visualEffects,
} from '../components/avatar/PixelAvatar';

const categories = [
  { id: 'face', label: 'Cara', icon: '😊', color: 'from-pink-400 to-rose-500' },
  { id: 'skin', label: 'Piel', icon: '🎨', color: 'from-amber-400 to-orange-500' },
  { id: 'hair', label: 'Cabello', icon: '💇', color: 'from-purple-400 to-pink-500' },
  { id: 'shirt', label: 'Camisa', icon: '👕', color: 'from-blue-400 to-cyan-500' },
  { id: 'pants', label: 'Pantalón', icon: '👖', color: 'from-indigo-400 to-purple-500' },
  { id: 'shoes', label: 'Zapatos', icon: '👟', color: 'from-green-400 to-emerald-500' },
  { id: 'accessories', label: 'Accesorios', icon: '🎀', color: 'from-rose-400 to-pink-500' },
  { id: 'effects', label: 'Efectos', icon: '✨', color: 'from-yellow-400 to-orange-500' },
];

const animationOptions = [
  { id: 'idle', icon: '🧍', label: 'Quieto' },
  { id: 'wave', icon: '👋', label: 'Saludo' },
  { id: 'dance', icon: '💃', label: 'Bailar' },
  { id: 'jump', icon: '🦘', label: 'Saltar' },
  { id: 'bounce', icon: '⬆️', label: 'Rebotar' },
  { id: 'spin', icon: '🔄', label: 'Girar' },
  { id: 'float', icon: '☁️', label: 'Flotar' },
  { id: 'excited', icon: '🤩', label: 'Emoción' },
  { id: 'sleep', icon: '😴', label: 'Dormir' },
  { id: 'none', icon: '⏸️', label: 'Estático' },
];

export default function AvatarPage() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [activeCategory, setActiveCategory] = useState('face');
  const [previewAnimation, setPreviewAnimation] = useState('idle');
  const [outfits, setOutfits] = useState([]);
  const [showOutfitDialog, setShowOutfitDialog] = useState(false);
  const [newOutfitName, setNewOutfitName] = useState('');
  
  const [avatarConfig, setAvatarConfig] = useState({
    face: 'happy',
    skinColor: 'light',
    hairStyle: 'short',
    hairColor: 'brown',
    shirtStyle: 'tshirt',
    shirtColor: '#7e57c2',
    pantsStyle: 'jeans',
    pantsColor: '#2196f3',
    shoesStyle: 'sneakers',
    shoesColor: '#212121',
    hat: null,
    hatColor: '#3498db',
    glasses: null,
    scarf: null,
    scarfColor: '#e74c3c',
    gloves: null,
    glovesColor: '#1a1a1a',
    backpack: null,
    backpackColor: '#795548',
    pet: null,
    effect: null,
  });

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await db.auth.me();
      setUser(currentUser);
      if (currentUser.avatar_config) {
        setAvatarConfig({ ...avatarConfig, ...currentUser.avatar_config });
      }
      if (currentUser.saved_outfits) {
        setOutfits(currentUser.saved_outfits);
      }
    };
    loadUser();
  }, []);

  const handleSave = async () => {
    setIsSaving(true);
    await db.auth.updateMe({ avatar_config: avatarConfig });
    setIsSaving(false);
    toast.success('¡Avatar guardado!');
    navigate(createPageUrl('Dashboard'));
  };

  const saveOutfit = async () => {
    if (!newOutfitName.trim()) {
      toast.error('Ingresa un nombre para el outfit');
      return;
    }
    const newOutfit = {
      id: Date.now().toString(),
      name: newOutfitName,
      config: { ...avatarConfig },
      createdAt: new Date().toISOString()
    };
    const updatedOutfits = [...outfits, newOutfit];
    setOutfits(updatedOutfits);
    await db.auth.updateMe({ saved_outfits: updatedOutfits });
    setNewOutfitName('');
    setShowOutfitDialog(false);
    toast.success(`Outfit "${newOutfitName}" guardado!`);
  };

  const loadOutfit = (outfit) => {
    setAvatarConfig(outfit.config);
    toast.success(`Outfit "${outfit.name}" cargado!`);
  };

  const deleteOutfit = async (outfitId) => {
    const updatedOutfits = outfits.filter(o => o.id !== outfitId);
    setOutfits(updatedOutfits);
    await db.auth.updateMe({ saved_outfits: updatedOutfits });
    toast.success('Outfit eliminado');
  };

  const updateConfig = (key, value) => {
    setAvatarConfig(prev => ({ ...prev, [key]: value }));
    setPreviewAnimation('jump');
    setTimeout(() => setPreviewAnimation('idle'), 600);
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-violet-50 via-purple-50 to-fuchsia-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-violet-600"></div>
      </div>
    );
  }

  const previewUser = { ...user, avatar_config: avatarConfig };

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-purple-50 to-fuchsia-50 p-4 md:p-8 pb-24">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-4">
            <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl('Dashboard'))} className="rounded-full border-2 border-violet-200">
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-violet-600 via-purple-600 to-fuchsia-600 bg-clip-text text-transparent">
                Personaliza tu Avatar
              </h1>
              <p className="text-gray-600 mt-1">Crea tu personaje único estilo pixel art</p>
            </div>
          </div>
          
          {/* Outfits Button */}
          <Dialog open={showOutfitDialog} onOpenChange={setShowOutfitDialog}>
            <DialogTrigger asChild>
              <Button variant="outline" className="border-2 border-violet-300">
                <FolderOpen className="w-4 h-4 mr-2" />
                Outfits ({outfits.length})
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <FolderOpen className="w-5 h-5 text-violet-600" />
                  Mis Outfits Guardados
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4">
                {/* Save new outfit */}
                <div className="flex gap-2">
                  <Input
                    placeholder="Nombre del outfit..."
                    value={newOutfitName}
                    onChange={(e) => setNewOutfitName(e.target.value)}
                  />
                  <Button onClick={saveOutfit} className="bg-violet-600">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                
                {/* Saved outfits list */}
                <div className="space-y-2 max-h-[300px] overflow-y-auto">
                  {outfits.length === 0 ? (
                    <p className="text-center text-gray-500 py-4">No tienes outfits guardados</p>
                  ) : (
                    outfits.map((outfit) => (
                      <motion.div
                        key={outfit.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl border"
                      >
                        <div className="w-12 h-16">
                          <PixelAvatar user={{ avatar_config: outfit.config }} size="small" showLevel={false} animation="none" />
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-gray-800">{outfit.name}</p>
                          <p className="text-xs text-gray-500">
                            {new Date(outfit.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex gap-1">
                          <Button size="sm" variant="ghost" onClick={() => loadOutfit(outfit)}>
                            <Wand2 className="w-4 h-4 text-violet-600" />
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => deleteOutfit(outfit.id)}>
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </Button>
                        </div>
                      </motion.div>
                    ))
                  )}
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid lg:grid-cols-[380px_1fr] gap-6">
          {/* Preview Panel */}
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="lg:sticky lg:top-4 h-fit">
            <Card className="overflow-hidden border-2 border-violet-200 shadow-xl">
              <div className="bg-gradient-to-r from-violet-600 via-purple-600 to-fuchsia-600 p-4 text-center">
                <h2 className="text-white font-bold text-lg flex items-center justify-center gap-2">
                  <User className="w-5 h-5" /> Vista Previa
                </h2>
              </div>
              <div className="p-8 bg-gradient-to-br from-violet-100 via-purple-50 to-fuchsia-100 flex flex-col items-center">
                <motion.div
                  key={JSON.stringify(avatarConfig)}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: "spring", stiffness: 200 }}
                >
                  <PixelAvatar user={previewUser} size="xlarge" showLevel={true} showCoins={true} animation={previewAnimation} />
                </motion.div>
                
                {/* Animation selector */}
                <div className="mt-4 w-full">
                  <p className="text-xs font-medium text-gray-600 mb-2 text-center">Animación</p>
                  <div className="grid grid-cols-5 gap-1">
                    {animationOptions.map((anim) => (
                      <Button
                        key={anim.id}
                        size="sm"
                        variant={previewAnimation === anim.id ? "default" : "outline"}
                        onClick={() => setPreviewAnimation(anim.id)}
                        className={cn("text-lg p-1 h-10", previewAnimation === anim.id && "bg-violet-600")}
                        title={anim.label}
                      >
                        {anim.icon}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
              <div className="p-4 bg-white border-t border-violet-100 grid grid-cols-2 gap-3">
                <div className="bg-amber-50 rounded-xl p-3 border border-amber-200 text-center">
                  <p className="text-xs text-amber-600 font-medium">Nivel</p>
                  <p className="text-2xl font-bold text-amber-700">{user?.level || 1}</p>
                </div>
                <div className="bg-violet-50 rounded-xl p-3 border border-violet-200 text-center">
                  <p className="text-xs text-violet-600 font-medium">Monedas</p>
                  <p className="text-2xl font-bold text-violet-700">💰 {user?.coins || 0}</p>
                </div>
              </div>
            </Card>
          </motion.div>

          {/* Customization Panel */}
          <div className="space-y-4">
            {/* Category Tabs */}
            <div className="flex flex-wrap gap-2">
              {categories.map((cat) => (
                <motion.button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={cn(
                    "flex items-center gap-2 px-3 py-2 rounded-xl font-semibold transition-all border-2 text-sm",
                    activeCategory === cat.id
                      ? `bg-gradient-to-r ${cat.color} text-white border-transparent shadow-lg`
                      : "bg-white text-gray-600 border-gray-200 hover:border-violet-300"
                  )}
                >
                  <span className="text-lg">{cat.icon}</span>
                  <span className="hidden sm:inline">{cat.label}</span>
                </motion.button>
              ))}
            </div>

            <AnimatePresence mode="wait">
              {/* Face Selection */}
              {activeCategory === 'face' && (
                <motion.div key="face" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
                  <Card className="p-6 bg-white border-2 border-violet-100 shadow-lg">
                    <Label className="text-xl font-bold mb-4 flex items-center gap-2 text-gray-800">
                      😊 Expresión Facial
                    </Label>
                    <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
                      {Object.entries(faceExpressions).map(([id, face]) => (
                        <motion.button
                          key={id}
                          onClick={() => updateConfig('face', id)}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className={cn(
                            "p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2",
                            avatarConfig.face === id
                              ? "border-pink-500 bg-gradient-to-br from-pink-50 to-rose-50 shadow-lg"
                              : "border-gray-200 hover:border-pink-300 bg-gray-50"
                          )}
                        >
                          <div className="w-14 h-16 flex items-center justify-center">
                            <PixelAvatar user={{ avatar_config: { ...avatarConfig, face: id } }} size="small" showLevel={false} animation="none" />
                          </div>
                          <span className="text-[10px] font-medium text-gray-600 truncate w-full text-center">{face.name}</span>
                        </motion.button>
                      ))}
                    </div>
                  </Card>
                </motion.div>
              )}

              {/* Skin Selection */}
              {activeCategory === 'skin' && (
                <motion.div key="skin" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
                  <Card className="p-6 bg-white border-2 border-violet-100 shadow-lg space-y-6">
                    <Label className="text-xl font-bold flex items-center gap-2 text-gray-800">
                      <Palette className="w-6 h-6 text-amber-500" /> Tono de Piel
                    </Label>
                    
                    <div>
                      <p className="text-sm font-medium text-gray-600 mb-3">Tonos Naturales</p>
                      <div className="grid grid-cols-5 sm:grid-cols-10 gap-3">
                        {Object.entries(skinTones).slice(0, 10).map(([id, tone]) => (
                          <motion.button key={id} onClick={() => updateConfig('skinColor', id)} whileHover={{ scale: 1.15, y: -3 }} className="flex flex-col items-center gap-1">
                            <div className={cn("w-10 h-10 rounded-xl border-4 transition-all shadow-md", avatarConfig.skinColor === id ? "border-violet-500 ring-4 ring-violet-200 scale-110" : "border-white hover:border-violet-300")} style={{ backgroundColor: tone.base }} />
                          </motion.button>
                        ))}
                      </div>
                    </div>

                    <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-4 border border-purple-200">
                      <p className="text-sm font-medium text-purple-700 mb-3 flex items-center gap-2"><Sparkles className="w-4 h-4" /> Tonos Fantasía</p>
                      <div className="grid grid-cols-5 sm:grid-cols-10 gap-3">
                        {Object.entries(skinTones).slice(10).map(([id, tone]) => (
                          <motion.button key={id} onClick={() => updateConfig('skinColor', id)} whileHover={{ scale: 1.15, y: -3 }} className="flex flex-col items-center gap-1">
                            <div className={cn("w-10 h-10 rounded-xl border-4 transition-all shadow-md", avatarConfig.skinColor === id ? "border-purple-500 ring-4 ring-purple-200 scale-110" : "border-white hover:border-purple-300")} style={{ backgroundColor: tone.base }} />
                          </motion.button>
                        ))}
                      </div>
                    </div>
                  </Card>
                </motion.div>
              )}

              {/* Hair Selection */}
              {activeCategory === 'hair' && (
                <motion.div key="hair" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-4">
                  <Card className="p-6 bg-white border-2 border-violet-100 shadow-lg">
                    <Label className="text-xl font-bold mb-4 flex items-center gap-2 text-gray-800">
                      <Scissors className="w-6 h-6 text-pink-500" /> Estilo de Cabello
                    </Label>
                    <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-6 gap-3 max-h-[220px] overflow-y-auto pr-2">
                      {Object.entries(hairStyles).map(([id, style]) => (
                        <motion.button key={id} onClick={() => updateConfig('hairStyle', id)} whileHover={{ scale: 1.05 }} className={cn("p-2 rounded-xl border-2 transition-all flex flex-col items-center gap-1", avatarConfig.hairStyle === id ? "border-pink-500 bg-pink-50 shadow-lg" : "border-gray-200 hover:border-pink-300 bg-gray-50")}>
                          <div className="w-12 h-14 flex items-center justify-center">
                            <PixelAvatar user={{ avatar_config: { ...avatarConfig, hairStyle: id } }} size="small" showLevel={false} animation="none" />
                          </div>
                          <span className="text-[9px] font-medium text-gray-600">{style.name}</span>
                        </motion.button>
                      ))}
                    </div>
                  </Card>

                  <Card className="p-6 bg-white border-2 border-violet-100 shadow-lg">
                    <Label className="text-lg font-bold mb-4 text-gray-800">🎨 Color de Cabello</Label>
                    <div className="grid grid-cols-10 gap-2">
                      {Object.entries(hairColors).map(([id, color]) => (
                        <motion.button key={id} onClick={() => updateConfig('hairColor', id)} whileHover={{ scale: 1.2 }} className={cn("w-7 h-7 rounded-lg border-3 transition-all shadow-sm", avatarConfig.hairColor === id ? "border-violet-500 ring-2 ring-violet-300 scale-110" : "border-gray-200")} style={{ backgroundColor: color.base }} />
                      ))}
                    </div>
                  </Card>
                </motion.div>
              )}

              {/* Shirt Selection */}
              {activeCategory === 'shirt' && (
                <motion.div key="shirt" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-4">
                  <Card className="p-6 bg-white border-2 border-violet-100 shadow-lg">
                    <Label className="text-xl font-bold mb-4 flex items-center gap-2 text-gray-800">
                      <Shirt className="w-6 h-6 text-blue-500" /> Estilo de Camisa
                    </Label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {Object.entries(shirtStyles).map(([id, style]) => (
                        <motion.button key={id} onClick={() => updateConfig('shirtStyle', id)} whileHover={{ scale: 1.05 }} className={cn("p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2", avatarConfig.shirtStyle === id ? "border-blue-500 bg-blue-50 shadow-lg" : "border-gray-200 hover:border-blue-300 bg-gray-50")}>
                          <div className="w-14 h-18 flex items-center justify-center">
                            <PixelAvatar user={{ avatar_config: { ...avatarConfig, shirtStyle: id } }} size="small" showLevel={false} animation="none" />
                          </div>
                          <span className="text-xs font-medium text-gray-600">{style.name}</span>
                        </motion.button>
                      ))}
                    </div>
                  </Card>
                  <Card className="p-6 bg-white border-2 border-violet-100 shadow-lg">
                    <Label className="text-lg font-bold mb-4 text-gray-800">🎨 Color de Camisa</Label>
                    <div className="grid grid-cols-11 gap-2">
                      {Object.entries(clothingColors).map(([id, color]) => (
                        <motion.button key={id} onClick={() => updateConfig('shirtColor', color)} whileHover={{ scale: 1.2 }} className={cn("w-7 h-7 rounded-lg border-3 transition-all", avatarConfig.shirtColor === color ? "border-blue-500 ring-2 ring-blue-300 scale-110" : "border-gray-200")} style={{ backgroundColor: color }} />
                      ))}
                    </div>
                  </Card>
                </motion.div>
              )}

              {/* Pants Selection */}
              {activeCategory === 'pants' && (
                <motion.div key="pants" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-4">
                  <Card className="p-6 bg-white border-2 border-violet-100 shadow-lg">
                    <Label className="text-xl font-bold mb-4 text-gray-800">👖 Estilo de Pantalón</Label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {Object.entries(pantsStyles).map(([id, style]) => (
                        <motion.button key={id} onClick={() => updateConfig('pantsStyle', id)} whileHover={{ scale: 1.05 }} className={cn("p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2", avatarConfig.pantsStyle === id ? "border-indigo-500 bg-indigo-50 shadow-lg" : "border-gray-200 bg-gray-50")}>
                          <div className="w-14 h-18 flex items-center justify-center">
                            <PixelAvatar user={{ avatar_config: { ...avatarConfig, pantsStyle: id } }} size="small" showLevel={false} animation="none" />
                          </div>
                          <span className="text-xs font-medium text-gray-600">{style.name}</span>
                        </motion.button>
                      ))}
                    </div>
                  </Card>
                  <Card className="p-6 bg-white border-2 border-violet-100 shadow-lg">
                    <Label className="text-lg font-bold mb-4 text-gray-800">🎨 Color de Pantalón</Label>
                    <div className="grid grid-cols-11 gap-2">
                      {Object.entries(clothingColors).map(([id, color]) => (
                        <motion.button key={id} onClick={() => updateConfig('pantsColor', color)} whileHover={{ scale: 1.2 }} className={cn("w-7 h-7 rounded-lg border-3 transition-all", avatarConfig.pantsColor === color ? "border-indigo-500 ring-2 ring-indigo-300 scale-110" : "border-gray-200")} style={{ backgroundColor: color }} />
                      ))}
                    </div>
                  </Card>
                </motion.div>
              )}

              {/* Shoes Selection */}
              {activeCategory === 'shoes' && (
                <motion.div key="shoes" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-4">
                  <Card className="p-6 bg-white border-2 border-violet-100 shadow-lg">
                    <Label className="text-xl font-bold mb-4 text-gray-800">👟 Estilo de Zapatos</Label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {Object.entries(shoesStyles).map(([id, style]) => (
                        <motion.button key={id} onClick={() => updateConfig('shoesStyle', id)} whileHover={{ scale: 1.05 }} className={cn("p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2", avatarConfig.shoesStyle === id ? "border-green-500 bg-green-50 shadow-lg" : "border-gray-200 bg-gray-50")}>
                          <div className="w-14 h-18 flex items-center justify-center">
                            <PixelAvatar user={{ avatar_config: { ...avatarConfig, shoesStyle: id } }} size="small" showLevel={false} animation="none" />
                          </div>
                          <span className="text-xs font-medium text-gray-600">{style.name}</span>
                        </motion.button>
                      ))}
                    </div>
                  </Card>
                  <Card className="p-6 bg-white border-2 border-violet-100 shadow-lg">
                    <Label className="text-lg font-bold mb-4 text-gray-800">🎨 Color de Zapatos</Label>
                    <div className="grid grid-cols-11 gap-2">
                      {Object.entries(clothingColors).map(([id, color]) => (
                        <motion.button key={id} onClick={() => updateConfig('shoesColor', color)} whileHover={{ scale: 1.2 }} className={cn("w-7 h-7 rounded-lg border-3 transition-all", avatarConfig.shoesColor === color ? "border-green-500 ring-2 ring-green-300 scale-110" : "border-gray-200")} style={{ backgroundColor: color }} />
                      ))}
                    </div>
                  </Card>
                </motion.div>
              )}

              {/* Accessories Selection */}
              {activeCategory === 'accessories' && (
                <motion.div key="accessories" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-4">
                  {/* Hats */}
                  <Card className="p-6 bg-white border-2 border-violet-100 shadow-lg">
                    <Label className="text-xl font-bold mb-4 text-gray-800">🎩 Sombreros</Label>
                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
                      <motion.button onClick={() => updateConfig('hat', null)} whileHover={{ scale: 1.05 }} className={cn("p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2", !avatarConfig.hat ? "border-rose-500 bg-rose-50 shadow-lg" : "border-gray-200 bg-gray-50")}>
                        <span className="text-2xl">❌</span>
                        <span className="text-xs font-medium text-gray-600">Ninguno</span>
                      </motion.button>
                      {Object.keys(accessories.hats).map((id) => (
                        <motion.button key={id} onClick={() => updateConfig('hat', id)} whileHover={{ scale: 1.05 }} className={cn("p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2", avatarConfig.hat === id ? "border-rose-500 bg-rose-50 shadow-lg" : "border-gray-200 bg-gray-50")}>
                          <div className="w-12 h-14 flex items-center justify-center">
                            <PixelAvatar user={{ avatar_config: { ...avatarConfig, hat: id } }} size="small" showLevel={false} animation="none" />
                          </div>
                          <span className="text-xs font-medium text-gray-600 capitalize">{id}</span>
                        </motion.button>
                      ))}
                    </div>
                  </Card>

                  {/* Glasses */}
                  <Card className="p-6 bg-white border-2 border-violet-100 shadow-lg">
                    <Label className="text-xl font-bold mb-4 text-gray-800">👓 Gafas</Label>
                    <div className="grid grid-cols-3 sm:grid-cols-5 gap-3">
                      <motion.button onClick={() => updateConfig('glasses', null)} whileHover={{ scale: 1.05 }} className={cn("p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2", !avatarConfig.glasses ? "border-blue-500 bg-blue-50 shadow-lg" : "border-gray-200 bg-gray-50")}>
                        <span className="text-2xl">❌</span>
                        <span className="text-xs font-medium text-gray-600">Ninguno</span>
                      </motion.button>
                      {Object.keys(accessories.glasses).map((id) => (
                        <motion.button key={id} onClick={() => updateConfig('glasses', id)} whileHover={{ scale: 1.05 }} className={cn("p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2", avatarConfig.glasses === id ? "border-blue-500 bg-blue-50 shadow-lg" : "border-gray-200 bg-gray-50")}>
                          <div className="w-12 h-14 flex items-center justify-center">
                            <PixelAvatar user={{ avatar_config: { ...avatarConfig, glasses: id } }} size="small" showLevel={false} animation="none" />
                          </div>
                          <span className="text-xs font-medium text-gray-600 capitalize">{id}</span>
                        </motion.button>
                      ))}
                    </div>
                  </Card>

                  {/* Scarves */}
                  <Card className="p-6 bg-white border-2 border-violet-100 shadow-lg">
                    <Label className="text-xl font-bold mb-4 text-gray-800">🧣 Bufandas</Label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <motion.button onClick={() => updateConfig('scarf', null)} whileHover={{ scale: 1.05 }} className={cn("p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2", !avatarConfig.scarf ? "border-red-500 bg-red-50 shadow-lg" : "border-gray-200 bg-gray-50")}>
                        <span className="text-2xl">❌</span>
                        <span className="text-xs font-medium text-gray-600">Ninguno</span>
                      </motion.button>
                      {Object.keys(accessories.scarves).map((id) => (
                        <motion.button key={id} onClick={() => updateConfig('scarf', id)} whileHover={{ scale: 1.05 }} className={cn("p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2", avatarConfig.scarf === id ? "border-red-500 bg-red-50 shadow-lg" : "border-gray-200 bg-gray-50")}>
                          <div className="w-12 h-14 flex items-center justify-center">
                            <PixelAvatar user={{ avatar_config: { ...avatarConfig, scarf: id } }} size="small" showLevel={false} animation="none" />
                          </div>
                          <span className="text-xs font-medium text-gray-600 capitalize">{id}</span>
                        </motion.button>
                      ))}
                    </div>
                    {avatarConfig.scarf && (
                      <div className="mt-4">
                        <Label className="text-sm font-bold mb-2 text-gray-800">Color de Bufanda</Label>
                        <div className="grid grid-cols-11 gap-2">
                          {Object.entries(clothingColors).slice(0, 11).map(([id, color]) => (
                            <motion.button key={id} onClick={() => updateConfig('scarfColor', color)} whileHover={{ scale: 1.2 }} className={cn("w-6 h-6 rounded-lg border-2 transition-all", avatarConfig.scarfColor === color ? "border-red-500 ring-2 ring-red-300" : "border-gray-200")} style={{ backgroundColor: color }} />
                          ))}
                        </div>
                      </div>
                    )}
                  </Card>

                  {/* Gloves */}
                  <Card className="p-6 bg-white border-2 border-violet-100 shadow-lg">
                    <Label className="text-xl font-bold mb-4 text-gray-800">🧤 Guantes</Label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <motion.button onClick={() => updateConfig('gloves', null)} whileHover={{ scale: 1.05 }} className={cn("p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2", !avatarConfig.gloves ? "border-amber-500 bg-amber-50 shadow-lg" : "border-gray-200 bg-gray-50")}>
                        <span className="text-2xl">❌</span>
                        <span className="text-xs font-medium text-gray-600">Ninguno</span>
                      </motion.button>
                      {Object.keys(accessories.gloves).map((id) => (
                        <motion.button key={id} onClick={() => updateConfig('gloves', id)} whileHover={{ scale: 1.05 }} className={cn("p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2", avatarConfig.gloves === id ? "border-amber-500 bg-amber-50 shadow-lg" : "border-gray-200 bg-gray-50")}>
                          <div className="w-12 h-14 flex items-center justify-center">
                            <PixelAvatar user={{ avatar_config: { ...avatarConfig, gloves: id } }} size="small" showLevel={false} animation="none" />
                          </div>
                          <span className="text-xs font-medium text-gray-600 capitalize">{id}</span>
                        </motion.button>
                      ))}
                    </div>
                  </Card>

                  {/* Backpacks */}
                  <Card className="p-6 bg-white border-2 border-violet-100 shadow-lg">
                    <Label className="text-xl font-bold mb-4 text-gray-800">🎒 Mochilas y Alas</Label>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                      <motion.button onClick={() => updateConfig('backpack', null)} whileHover={{ scale: 1.05 }} className={cn("p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2", !avatarConfig.backpack ? "border-emerald-500 bg-emerald-50 shadow-lg" : "border-gray-200 bg-gray-50")}>
                        <span className="text-2xl">❌</span>
                        <span className="text-xs font-medium text-gray-600">Ninguno</span>
                      </motion.button>
                      {Object.keys(accessories.backpacks).map((id) => (
                        <motion.button key={id} onClick={() => updateConfig('backpack', id)} whileHover={{ scale: 1.05 }} className={cn("p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2", avatarConfig.backpack === id ? "border-emerald-500 bg-emerald-50 shadow-lg" : "border-gray-200 bg-gray-50")}>
                          <div className="w-12 h-14 flex items-center justify-center">
                            <PixelAvatar user={{ avatar_config: { ...avatarConfig, backpack: id } }} size="small" showLevel={false} animation="none" />
                          </div>
                          <span className="text-xs font-medium text-gray-600 capitalize">{id}</span>
                        </motion.button>
                      ))}
                    </div>
                  </Card>
                </motion.div>
              )}

              {/* Effects & Pets */}
              {activeCategory === 'effects' && (
                <motion.div key="effects" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-4">
                  {/* Pets */}
                  <Card className="p-6 bg-white border-2 border-violet-100 shadow-lg">
                    <Label className="text-xl font-bold mb-4 flex items-center gap-2 text-gray-800">
                      <Heart className="w-5 h-5 text-pink-500" /> Mascotas
                    </Label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <motion.button onClick={() => updateConfig('pet', null)} whileHover={{ scale: 1.05 }} className={cn("p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2", !avatarConfig.pet ? "border-pink-500 bg-pink-50 shadow-lg" : "border-gray-200 bg-gray-50")}>
                        <span className="text-2xl">❌</span>
                        <span className="text-xs font-medium text-gray-600">Ninguna</span>
                      </motion.button>
                      {Object.entries(pets).map(([id, pet]) => (
                        <motion.button key={id} onClick={() => updateConfig('pet', id)} whileHover={{ scale: 1.05 }} className={cn("p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2", avatarConfig.pet === id ? "border-pink-500 bg-pink-50 shadow-lg" : "border-gray-200 bg-gray-50")}>
                          <div className="w-14 h-16 flex items-center justify-center">
                            <PixelAvatar user={{ avatar_config: { ...avatarConfig, pet: id } }} size="small" showLevel={false} animation="idle" />
                          </div>
                          <span className="text-xs font-medium text-gray-600">{pet.name}</span>
                        </motion.button>
                      ))}
                    </div>
                  </Card>

                  {/* Visual Effects */}
                  <Card className="p-6 bg-white border-2 border-violet-100 shadow-lg">
                    <Label className="text-xl font-bold mb-4 flex items-center gap-2 text-gray-800">
                      <Zap className="w-5 h-5 text-yellow-500" /> Efectos Visuales
                    </Label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <motion.button onClick={() => updateConfig('effect', null)} whileHover={{ scale: 1.05 }} className={cn("p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2", !avatarConfig.effect ? "border-yellow-500 bg-yellow-50 shadow-lg" : "border-gray-200 bg-gray-50")}>
                        <span className="text-2xl">❌</span>
                        <span className="text-xs font-medium text-gray-600">Ninguno</span>
                      </motion.button>
                      {Object.entries(visualEffects).map(([id, effect]) => (
                        <motion.button key={id} onClick={() => updateConfig('effect', id)} whileHover={{ scale: 1.05 }} className={cn("p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-2", avatarConfig.effect === id ? "border-yellow-500 bg-yellow-50 shadow-lg" : "border-gray-200 bg-gray-50")}>
                          <div className="w-14 h-16 flex items-center justify-center overflow-hidden">
                            <PixelAvatar user={{ avatar_config: { ...avatarConfig, effect: id } }} size="small" showLevel={false} animation="idle" />
                          </div>
                          <span className="text-xs font-medium text-gray-600">{effect.name}</span>
                        </motion.button>
                      ))}
                    </div>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Action Buttons */}
            <div className="space-y-3">
              <div className="flex gap-3">
                <Button variant="outline" onClick={() => navigate(createPageUrl('Dashboard'))} className="flex-1 border-2">Cancelar</Button>
                <Button onClick={handleSave} disabled={isSaving} className="flex-1 bg-gradient-to-r from-violet-600 to-fuchsia-600">
                  {isSaving ? 'Guardando...' : '✨ Guardar Avatar'}
                </Button>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Button onClick={() => navigate(createPageUrl('Shop'))} className="bg-gradient-to-r from-amber-500 to-orange-500 h-12">
                  <Store className="w-5 h-5 mr-2" /> Tienda
                </Button>
                <Button onClick={() => navigate(createPageUrl('Inventory'))} variant="outline" className="border-2 border-violet-300 h-12">
                  📦 Mi Inventario
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}