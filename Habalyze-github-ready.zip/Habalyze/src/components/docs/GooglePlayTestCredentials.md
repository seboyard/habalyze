# Google Play Test Credentials & Instructions

## Demo Account Credentials

**Email:** demo@habalyze.com  
**Password:** DemoHabalyze2025!

---

## Instructions for Testing (English)

### How to access restricted functionality:

1. **Login**: Use the demo credentials (demo@habalyze.com / DemoHabalyze2025!) to access the app. All features are available after login, including habits tracking, AI coach, social features, and gamification elements.

2. **Create Habits**: Navigate to the Dashboard and click the "+ New Habit" button to create daily habits. Complete habits to earn XP, coins, and level up your character.

3. **Access Premium Features**: The demo account has premium features enabled, including unlimited AI Coach messages, advanced statistics, and exclusive avatar customization options.

4. **Test Social Features**: Go to the Social tab to view friend activities, join challenges, and compete on leaderboards. The demo account has pre-configured friendships for testing.

5. **Explore Gamification**: Visit the Shop to purchase avatar items with earned coins, check Achievements for unlockable rewards, and test the complete progression system with levels, badges, and missions.

---

## Alternative Test Account (Optional)

**Email:** tester@habalyze.com  
**Password:** TestHabalyze2025!

---

## Notes

- Both accounts are fully functional with access to all app features
- Demo accounts have sample data pre-populated for immediate testing
- Premium features are enabled by default on test accounts
- All gamification elements (XP, coins, levels, achievements) are accessible
- Social features can be tested with pre-existing friendships and activities