export const rarityConfig = {
  common: { color: 'bg-gray-100 text-gray-700 border-gray-300', glow: '', label: 'Común' },
  rare: { color: 'bg-blue-100 text-blue-700 border-blue-300', glow: 'ring-2 ring-blue-200', label: 'Raro' },
  epic: { color: 'bg-purple-100 text-purple-700 border-purple-300', glow: 'ring-2 ring-purple-200', label: 'Épico' },
  legendary: { color: 'bg-amber-100 text-amber-700 border-amber-300', glow: 'ring-2 ring-amber-200 shadow-amber-200/50 shadow-lg', label: 'Legendario' },
  exclusive: { color: 'bg-gradient-to-r from-pink-100 to-purple-100 text-pink-700 border-pink-300', glow: 'ring-2 ring-pink-200 animate-pulse', label: 'Exclusivo' },
};

export const colorPalette = [
  '#e74c3c', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3',
  '#03a9f4', '#00bcd4', '#009688', '#4caf50', '#8bc34a', '#cddc39',
  '#ffeb3b', '#ffc107', '#ff9800', '#ff5722', '#795548', '#9e9e9e',
  '#607d8b', '#1a1a1a', '#ffffff', '#f5f5dc',
];

export const shopCategories = [
  { id: 'all', label: 'Todo', icon: '✨' },
  { id: 'new', label: 'Novedades', icon: '🆕' },
  { id: 'popular', label: 'Populares', icon: '🔥' },
  { id: 'lootbox', label: 'Cajas', icon: '🎁' },
  { id: 'packs', label: 'Packs', icon: '📦' },
  { id: 'face', label: 'Caras', icon: '😈' },
  { id: 'skin', label: 'Pieles', icon: '🎭' },
  { id: 'hat', label: 'Sombreros', icon: '🎩' },
  { id: 'glasses', label: 'Gafas', icon: '👓' },
  { id: 'scarf', label: 'Collares', icon: '📿' },
  { id: 'gloves', label: 'Brazaletes', icon: '⌚' },
  { id: 'backpack', label: 'Alas/Capas', icon: '🦋' },
  { id: 'tattoo', label: 'Tatuajes', icon: '🎨' },
  { id: 'piercing', label: 'Piercings', icon: '💎' },
  { id: 'pet', label: 'Mascotas', icon: '🐾' },
  { id: 'effect', label: 'Efectos', icon: '⚡' },
];

export const categoryFieldMap = {
  'hat': { field: 'hat', colorField: 'hatColor' },
  'glasses': { field: 'glasses', colorField: 'glassesColor' },
  'scarf': { field: 'scarf', colorField: 'scarfColor' },
  'gloves': { field: 'gloves', colorField: 'glovesColor' },
  'backpack': { field: 'backpack', colorField: 'backpackColor' },
  'pet': { field: 'pet', colorField: 'petColor' },
  'effect': { field: 'effect', colorField: 'effectColor' },
  'tattoo': { field: 'tattoo', colorField: 'tattooColor' },
  'piercing': { field: 'piercing', colorField: 'piercingColor' },
  'face': { field: 'beardStyle', colorField: 'beardColor' },
  'shirt': { field: 'shirtStyle', colorField: 'shirtColor' },
};